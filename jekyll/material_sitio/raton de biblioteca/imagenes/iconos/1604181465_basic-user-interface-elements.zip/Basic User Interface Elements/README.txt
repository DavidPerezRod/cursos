Basic User Interface Elements
=============================

Designer: Stefan Taubert (https://www.iconfinder.com/stefantaubert)License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)