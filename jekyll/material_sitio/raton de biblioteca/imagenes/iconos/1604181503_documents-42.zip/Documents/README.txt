Documents
=========

Designer: Sergey Ershov (https://www.iconfinder.com/Fishmoby)
License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)
